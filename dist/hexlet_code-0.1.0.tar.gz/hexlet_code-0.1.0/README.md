# Brain Games

## Simple console Games to test basic knowledge of arithmetic

[![Actions Status](https://github.com/ErKir/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ErKir/python-project-49/actions) [![Maintainability](https://api.codeclimate.com/v1/badges/320e4f8dba53bccba4d3/maintainability)](https://codeclimate.com/github/ErKir/python-project-49/maintainability)
