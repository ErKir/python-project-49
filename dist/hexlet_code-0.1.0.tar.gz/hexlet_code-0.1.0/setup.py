# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'brain games',
    'long_description': '# Brain Games\n\n## Simple console Games to test basic knowledge of arithmetic\n\n[![Actions Status](https://github.com/ErKir/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ErKir/python-project-49/actions) [![Maintainability](https://api.codeclimate.com/v1/badges/320e4f8dba53bccba4d3/maintainability)](https://codeclimate.com/github/ErKir/python-project-49/maintainability)\n\n## Get started\n\nClone the repository and use `make package-install` command.\n\n## Games\n\n### Is even?\n\nAnswer "yes" if the number is *even*, otherwise answer "no".\n\nUse \'brain-even\' command to start.\n\n[![asciicast](https://asciinema.org/a/MBYq4CtaxhIz87gV5kXs7b5P6.svg)](https://asciinema.org/a/MBYq4CtaxhIz87gV5kXs7b5P6)\n',
    'author': 'ErKir',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
