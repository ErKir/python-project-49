# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'brain games',
    'long_description': '# Brain Games\n\n## Simple console Games to test basic knowledge of arithmetic\n\n[![Actions Status](https://github.com/ErKir/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ErKir/python-project-49/actions) [![Maintainability](https://api.codeclimate.com/v1/badges/320e4f8dba53bccba4d3/maintainability)](https://codeclimate.com/github/ErKir/python-project-49/maintainability)\n\n## Get started\n\nClone the repository and use `make package-install` command.\n\n## Games\n\n### Is even?\n\nAnswer "yes" if the number is *even*, otherwise answer "no".\n\nUse \'brain-even\' command to start.\n\n[![asciicast](https://asciinema.org/a/MBYq4CtaxhIz87gV5kXs7b5P6.svg)](https://asciinema.org/a/MBYq4CtaxhIz87gV5kXs7b5P6)\n\n### Calculator\n\nCalculate the result of the expression.\n\nUse \'brain-calc\' command to start.\n\n[![asciicast](https://asciinema.org/a/0sLcYVL3RLCtl1LrDYI9364lH.svg)](https://asciinema.org/a/0sLcYVL3RLCtl1LrDYI9364lH)\n\n### Greatest Common Divisor\n\nFind the greatest common divisor of given numbers.\n\nUse \'brain-gcd\' command to start.\n\n[![asciicast](https://asciinema.org/a/gGlHcc3qGfc95JQ77Jgf1x7LR.svg)](https://asciinema.org/a/gGlHcc3qGfc95JQ77Jgf1x7LR)\n\n### Progression game\n\nFined a missing number in the progression.\n\nUse \'brain-progression\' command to start.\n\n[![asciicast](https://asciinema.org/a/K3tad9qzp5QnAGntnTKfa9nPn.svg)](https://asciinema.org/a/K3tad9qzp5QnAGntnTKfa9nPn)\n\n### Is Prime?\n\nAnswer \'yes\' if given number is prime, otherwise answer \'no\'.\n\nUse \'brain-prime\' command to start.\n\n[![asciicast](https://asciinema.org/a/r5EEes9X364FZNYfhne34YTcy.svg)](https://asciinema.org/a/r5EEes9X364FZNYfhne34YTcy)\n',
    'author': 'ErKir',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
