import random


def get_random_num(min_number, max_number):
    return random.randint(min_number, max_number)
