#!/usr/bin/env python3

greeting = 'Welcome to the Brain Games!'


def greet():
    print(greeting)


def main():
    greet()


if __name__ == '__main__':
    main()
