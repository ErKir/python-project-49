from brain_games.games.gcd_game import game

# just starting game


def main():
    game()


if __name__ == '__main__':
    main()
