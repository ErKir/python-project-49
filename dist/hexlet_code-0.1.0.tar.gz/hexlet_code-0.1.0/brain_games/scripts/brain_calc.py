from brain_games.games.calc_game import game

# just starting game


def main():
    game()


if __name__ == '__main__':
    main()
