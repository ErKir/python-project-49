from brain_games.games.prime_game import game

# just starting game


def main():
    game()


if __name__ == '__main__':
    main()
