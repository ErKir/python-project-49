from brain_games.even_game import game

# just starting game
game()
